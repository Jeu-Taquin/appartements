export class Category{
    constructor(
      public _id:string,
      public label:string,
    ){}
  };
  export class Country{
    constructor(
      public _id:string,
      public label:string,
    ){}
  };