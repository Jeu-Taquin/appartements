export class Feedback{
    constructor(
      public _id:string,
      public name:string,
      public email:string,
      public message:string,
      public created_at:Date,
  
    ){}
  };