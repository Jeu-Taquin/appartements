
export const environment = {
  production: false,
  stripe:{
    testKey:'pk_test_51JQTe0BFPZUgGWqOFkcsx1W9Fkp5WA8Xdqx4wTvIX38Wu7dsSBG42IzmZ8TJKv809juTNB9ArEYqUEroEJKzMEO100ea86nWUF'
  }
};
export const BASE_URL= 'http://localhost:3000';
export const PAGNATION_PAGE= 6;


