# apartement-rent-project
-  npm install
-  cd client
-  npm install
-  create a .env file inside the /server/config with the following variable : MONGO_URI, JWT_SECRET, NODE_env,PORT
-  npm run server (to run the backend )
-  npm start (to run the fontend)
-  npm run dev (to run dev server for both backend and fontend)
